/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/15 20:39:33 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/19 14:26:50 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] && s2[i] && s1[i] == s2[i])
	{
		i++;
	}
	return (s1[i] - s2[i]);
}

// #include <stdio.h>
// #include <string.h>

// void	test(char *s1, char *s2)
// {
// 	int	ft;
// 	int	orig;

// 	ft = ft_strcmp(s1, s2);
// 	orig = strcmp(s1, s2);

// 	printf("s1: \"%s\" | s2: \"%s\"\n", s1, s2);
// 	printf("ft_strncmp: %d | strncmp: %d", ft, orig);

// 	if ((ft == 0 && orig == 0) || (ft < 0 && orig < 0) || (ft > 0 && orig > 0))
// 		printf(" ✅ OK\n\n");
// 	else
// 		printf(" ❌ KO\n\n");
// }

// int	main(void)
// {
// 	// básicos
// 	test("abc", "abc");
// 	test("abc", "abd");
// 	test("abc", "abd");

// 	// strings vazias
// 	test("", "");
// 	test("abc", "");
// 	test("", "abc");

// 	// tamanhos diferentes
// 	test("abc", "abcd");
// 	test("abcd", "abc");

// 	// diferença de case
// 	test("abc", "Abc");
// 	test("ABC", "abc");

// 	// diferença no final
// 	test("teste1", "teste2");
// 	test("teste1", "teste2");
// 	return (0);
// }