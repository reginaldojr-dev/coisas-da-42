/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 15:10:25 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/19 14:48:08 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && (s1[i] || s2[i]))
	{
		if (s1[i] != s2[i])
		{
			return ((unsigned char)s1[i] - (unsigned char)s2[i]);
		}
		i++;
	}
	return (0);
}

// #include <stdio.h>
// #include <string.h>

// void	test(char *s1, char *s2, unsigned int n)
// {
// 	int	ft;
// 	int	orig;

// 	ft = ft_strncmp(s1, s2, n);
// 	orig = strncmp(s1, s2, n);

// 	printf("s1: \"%s\" | s2: \"%s\" | n: %d\n", s1, s2, n);
// 	printf("ft_strncmp: %d | strncmp: %d", ft, orig);

// 	if ((ft == 0 && orig == 0) || (ft < 0 && orig < 0) || (ft > 0 && orig > 0))
// 		printf(" ✅ OK\n\n");
// 	else
// 		printf(" ❌ KO\n\n");
// }

// int	main(void)
// {
// 	// básicos
// 	test("abc", "abc", 3);
// 	test("abc", "abd", 3);
// 	test("abc", "abd", 2);

// 	// n = 0
// 	test("abc", "xyz", 0);

// 	// strings vazias
// 	test("", "", 5);
// 	test("abc", "", 5);
// 	test("", "abc", 5);

// 	// tamanhos diferentes
// 	test("abc", "abcd", 5);
// 	test("abcd", "abc", 5);

// 	// n menor que tamanho
// 	test("abcdef", "abcxyz", 3);
// 	test("abcdef", "abcxyz", 4);

// 	// diferença de case
// 	test("abc", "Abc", 3);
// 	test("ABC", "abc", 3);

// 	// diferença no final
// 	test("teste1", "teste2", 6);
// 	test("teste1", "teste2", 5);

// 	// n maior que tamanho
// 	test("oi", "oi", 10);
// 	test("oi", "ola", 10);

// 	return (0);
// }