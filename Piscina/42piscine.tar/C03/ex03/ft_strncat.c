/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 17:41:59 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/19 16:13:43 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char			*save;
	unsigned int	i;

	save = dest;
	while (*dest)
	{
		dest++;
	}
	i = 0;
	while (i < nb && src[i])
	{
		*dest = src[i];
		dest++;
		i++;
	}
	*dest = '\0';
	return (save);
}

// #include <stdio.h>
// #include <string.h>

// void	test(char *dest_init, char *src, unsigned int nb)
// {
// 	char dest1[100];
// 	char dest2[100];

// 	strcpy(dest1, dest_init);
// 	strcpy(dest2, dest_init);

// 	ft_strncat(dest1, src, nb);
// 	strncat(dest2, src, nb);

// 	printf("dest inicial: \"%s\"\n", dest_init);
// 	printf("src: \"%s\" | nb: %u\n", src, nb);
// 	printf("ft_strncat: \"%s\"\n", dest1);
// 	printf("strncat   : \"%s\"\n", dest2);
// 	printf("-----------------------------\n");
// }

// int	main(void)
// {
// 	// Teste 1: básico
// 	test("Hello", " World", 6);

// 	// Teste 2: nb menor que src
// 	test("Hello", " World", 3);

// 	// Teste 3: nb = 0
// 	test("Hello", " World", 0);

// 	// Teste 4: src vazia
// 	test("Hello", "", 5);

// 	// Teste 5: dest vazia
// 	test("", "Hello", 5);

// 	// Teste 6: nb maior que src
// 	test("Hi", " there", 100);

// 	// Teste 7: strings iguais
// 	test("Test", "Test", 4);

// 	// Teste 8: caracteres especiais
// 	test("Oi", "!!!@@@", 3);

// 	return (0);
// }