/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 02:05:41 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/19 20:59:15 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	unsigned int	index;

	index = 0;
	while (str[index] != '\0')
	{
		index++;
	}
	return (index);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	len_dest;
	unsigned int	len_src;
	unsigned int	i;

	len_dest = ft_strlen(dest);
	len_src = ft_strlen(src);
	if (size <= len_dest)
	{
		return (size + len_dest);
	}
	i = 0;
	while (src[i] && len_dest + i < size - 1)
	{
		dest[len_dest + i] = src[i];
		i++;
	}
	dest[len_dest + i] = '\0';
	return (len_dest + len_src);
}
// #include <stdio.h>
// #include <string.h>

// // Função de teste
// void	test(char *desc, char *dest, char *src, unsigned int size)
// {
// 	char buffer[50];
// 	unsigned int result;
// 	unsigned int result2;

// 	// copiar dest original para buffer
// 	strcpy(buffer, dest);

// 	result = ft_strlcat(buffer, src, size);
// 	result2 = strlcat(buffer, src, size);

// 	printf("Teste: %s\n", desc);
// 	printf("dest inicial: \"%s\", src: \"%s\", size: %u\n", dest, src, size);
// 	printf("resultado: %u\n", result);
// 	printf("resultado: %u\n", result2);
// 	printf("dest final: \"%s\"\n", buffer);
// 	printf("\n");
// }

// int	main(void)
// {
// 	test("Concatenação normal",
// 		"Hello", " World", 20);

// 	test("Size menor que dest",
// 		"Hello", " World", 3);

// 	test("Size igual ao dest",
// 		"Hello", " World", 5);

// 	test("Size exato para concatenação",
// 		"Hello", " World", 11);

// 	test("Buffer pequeno",
// 		"Hi", " there!", 5);

// 	test("Dest vazio",
// 		"", "Test", 10);

// 	test("Src vazio",
// 		"Hello", "", 10);

// 	return (0);
// }