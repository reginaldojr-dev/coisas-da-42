/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 19:08:13 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/18 03:44:29 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;

	i = 0;
	if (!to_find[i])
		return (str);
	while (str[i])
	{
		j = 0;
		while (str[i + j] == to_find[j] && to_find[j])
			j++;
		if (!to_find[j])
			return (&str[i]);
		i++;
	}
	return (0);
}

// #include <stdio.h>

// int	main(void)
// {
//     char str[] = "Exemplo de texto longo";
//     char find[] = "texto";

//     char *result = ft_strstr(str, find);

//     if(result)
//         printf("%s\n", result);
//     else
//         printf("não encontrado");

//     return(0);
// }
