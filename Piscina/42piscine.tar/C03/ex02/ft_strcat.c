/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 15:59:55 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/19 14:48:28 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	char	*save;

	save = dest;
	while (*dest)
	{
		dest++;
	}
	while (*src)
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (save);
}

// #include <stdio.h>
// #include <string.h>

// int main(void)
// {
// 	char	dest1[50] = "Hello, ";
// 	char	dest2[50] = "Hello, ";
// 	char	src[] = "World!";

// 	printf("Antes:\n");
// 	printf("dest1: %s\n", dest1);
// 	printf("dest2: %s\n", dest2);

// 	ft_strcat(dest1, src);
// 	strcat(dest2, src);

// 	printf("\nDepois:\n");
// 	printf("ft_strcat: %s\n", dest1);
// 	printf("strcat   : %s\n", dest2);

// 	if (strcmp(dest1, dest2) == 0)
// 		printf("\nResultado: OK ✅\n");
// 	else
// 		printf("\nResultado: KO ❌\n");

// 	return (0);
// }