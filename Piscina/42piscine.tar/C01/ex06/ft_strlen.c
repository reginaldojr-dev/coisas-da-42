/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/10 12:44:41 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/13 17:04:54 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	index;

	index = 0;
	while (str[index] != '\0')
	{
		index++;
	}
	return (index);
}

// #include <stdio.h>

// int	main(void)
// {
// 	char	str[] = "testando";
// 	int	size;
// 	size = ft_strlen(str);

// 	printf("%d\n", size);
// 	return (0);
// }
