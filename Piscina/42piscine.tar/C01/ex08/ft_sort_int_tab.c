/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/10 13:13:47 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/11 20:24:58 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int	index;
	int	position;
	int	temp;

	index = 0;
	while (index < size - 1)
	{
		position = 0;
		while (position < size - 1)
		{
			if (tab[position] > tab[position + 1])
			{
				temp = tab[position];
				tab[position] = tab[position + 1];
				tab[position + 1] = temp;
				temp = tab[position + 1];
			}
			position++;
		}
		index++;
	}
}

// #include <stdio.h>
// int main(void)
// {
// int array[10] = {18, 5, 29, 55, 4, 12, 23, 89, 2, 7};
// int size = 10;

// int print = 0;

// ft_sort_int_tab(array,size);

// while (print < size)
// {
// printf("%d, ", array[print]);
// print++;
// }
// return (0);
// }