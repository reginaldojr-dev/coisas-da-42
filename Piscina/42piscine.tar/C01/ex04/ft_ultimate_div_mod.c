/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/09 13:45:09 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/09 16:34:01 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	tmp;

	tmp = *a;
	*a = *a / *b;
	*b = tmp % *b;
}
//#include <stdio.h>

//int	main(void)
//{
//	int a;
//	int b;
//	
//	a = 10;
//	b = 3;
//	printf("Antes a = %d\n", a);
//	printf("Antes b = %d\n", b);

//	ft_ultimate_div_mod(&a, &b);
//	printf("Depois a = %d\n", a);
//	printf("Depois b = %d\n", b);
//}
