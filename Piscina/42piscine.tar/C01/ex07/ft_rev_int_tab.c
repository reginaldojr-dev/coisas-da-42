/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/10 13:13:47 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/10 14:34:42 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	index;
	int	temp;

	index = 0;
	while (index < size / 2)
	{
		temp = tab[index];
		tab[index] = tab[size - 1 - index];
		tab[size -1 - index] = temp;
		index++;
	}
}

//#include <stdio.h>
// int main(void)
// {
// int array[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
// int size = 10;

// int print = 0;

// ft_rev_int_tab(array,size);

// while (print < size)
// {
// printf("%d", array[print]);
// print++;
// }
// return (0);
// }