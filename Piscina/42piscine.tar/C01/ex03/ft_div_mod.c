/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/09 13:45:09 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/09 13:56:44 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}
//#include <stdio.h>

//int	main(void)
//{
//	int div;
//	int mod;

//	ft_div_mod(10, 3, &div, &mod);
//	printf("Divisão = %d\n", div);
//	printf("Resto = %d\n", mod);
//}
