/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/03 10:39:00 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/03 15:50:19 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print(char centena, char dezena, char unidade)
{
	write(1, &centena, 1);
	write(1, &dezena, 1);
	write(1, &unidade, 1);
	if (centena == '7' && dezena == '8' && unidade == '9')
		write(1, "", 1);
	else
	{
		write(1, ",", 1);
		write(1, " ", 1);
	}
}

void	ft_print_comb(void)
{
	char	unidade;
	char	dezena;
	char	centena;

	centena = '0' -1;
	while (++centena <= '7')
	{
		dezena = centena;
		while (++dezena <= '8')
		{
			unidade = dezena;
			while (++unidade <= '9')
			{
				ft_print(centena, dezena, unidade);
			}
		}
	}
}

//int	main(void)
//{
//	ft_print_comb();
//	return (0);
//}
