/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 13:38:13 by agde-mir          #+#    #+#             */
/*   Updated: 2026/03/19 21:05:35 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= '0' && str[i] <= '9'))
			return (0);
	i++;
	}
	return (1);
}

int	main(void)
{	
	char	str[] = "1";
	char	result;
	int		ans;

	ans = ft_str_is_numeric(str);
	result = ans + '0';
	write(1, &result, 1);
	return (0);
}
