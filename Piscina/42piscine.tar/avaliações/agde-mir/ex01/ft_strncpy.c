/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 13:35:53 by agde-mir          #+#    #+#             */
/*   Updated: 2026/03/19 21:03:53 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	while (i < n)
	{
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

int	main(void)
{
	unsigned int	n = 3;
	char	src[7] = "duvido";
	char	dest[7] = "será";

	ft_strncpy (dest, src, n);
	write (1, dest, 3);
	return (0);
}
