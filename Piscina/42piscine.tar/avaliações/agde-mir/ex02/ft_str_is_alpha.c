/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 13:36:21 by agde-mir          #+#    #+#             */
/*   Updated: 2026/03/19 21:04:56 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!((str[i] >= 'a' && str[i] <= 'z')
				|| (str[i] >= 'A' && str[i] <= 'Z' )))
			return (0);
	i++;
	}
	return (1);
}

int	main(void)
{	
	char	str[] = "asfas";
	char	result;
	int		ans;

	ans = ft_str_is_alpha(str);
	result = ans + '0';
	write(1, &result, 1);
	return (0);
}
