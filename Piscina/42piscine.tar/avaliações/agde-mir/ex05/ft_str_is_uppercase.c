/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 13:39:57 by agde-mir          #+#    #+#             */
/*   Updated: 2026/03/19 21:09:21 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!((str[i] >= 'A' && str[i] <= 'Z')))
			return (0);
	i++;
	}
	return (1);
}

int	main(void)
{	
	char	str[] = "a";
	char	result;
	int		ans;

	ans = ft_str_is_uppercase(str);
	result = ans + '0';
	write(1, &result, 1);
	return (0);
}
