/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 13:40:21 by agde-mir          #+#    #+#             */
/*   Updated: 2026/03/19 21:06:00 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!((str[i] >= 32 && str[i] <= 126)))
			return (0);
	i++;
	}
	return (1);
}

int	main(void)
{
	char	str[] = "";
	char	result;
	int		ans;

	ans = ft_str_is_printable(str);
	result = ans + '0';
	write(1, &result, 1);
	return (0);
}
