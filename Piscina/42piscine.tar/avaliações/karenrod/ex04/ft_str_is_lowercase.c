/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 14:07:57 by karenrod          #+#    #+#             */
/*   Updated: 2026/03/19 15:33:50 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}

int	main(void)
{
	char	*teste1;
	char	*teste2;
	char	*teste3;
	char	*teste4;

	teste1 = "neyde";
	teste2 = "NEYDe";
	teste3 = "2026";
	teste4 = "";
	printf("teste1:%d\n", ft_str_is_lowercase(teste1));
	printf("teste2:%d\n", ft_str_is_lowercase(teste2));
	printf("teste3:%d\n", ft_str_is_lowercase(teste3));
	printf("teste4:%d\n", ft_str_is_lowercase(teste4));
	return (0);
}
