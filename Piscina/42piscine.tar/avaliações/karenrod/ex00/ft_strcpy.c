/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 13:03:33 by karenrod          #+#    #+#             */
/*   Updated: 2026/03/19 15:25:13 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

#include <stdio.h>
int	main(void)
{
	char	destino[20];
	char	*ptrderetorno;
	char	origem[] = "Eu me remexo muito";

	printf("frase antes da função é:%s\n", origem);
	ptrderetorno = ft_strcpy(destino, origem);
	printf("Frase copiada é:%s\n", destino);
	return (0);
}
