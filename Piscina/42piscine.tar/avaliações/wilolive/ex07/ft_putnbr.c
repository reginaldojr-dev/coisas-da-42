/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wilolive <wilolive@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/03 12:25:14 by wilolive          #+#    #+#             */
/*   Updated: 2026/03/04 20:22:42 by wilolive         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <limits.h>
#include <unistd.h>
#define MAX_DIGITS 10

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

long	digits_count(long *nb)
{
	long	num;
	long	digits;

	num = *nb;
	digits = 0;
	while (num > 0)
	{
		num = num / 10;
		digits++;
	}
	if (*nb == 0)
		digits = 1;
	return (digits);
}

void	populate_arr(long *nb, long *nb_arr, long arr_len)
{
	long	idx;
	long	num;

	num = *nb;
	idx = arr_len -1;
	while (idx >= 0)
	{
		nb_arr[idx] = num % 10;
		num = num / 10;
		idx--;
	}
}

void	write_arr(long *nb_arr, long arr_len)
{
	long	idx;

	idx = 0;
	while (idx < arr_len)
	{
		ft_putchar(nb_arr[idx] + 48);
		idx++;
	}		
}

void	ft_putnbr(int nb)
{
	long	*nb_ptr;
	long	nbcpy;
	long	arr_len;
	long	nb_arr[MAX_DIGITS];

	if (nb < 0)
	{
		nbcpy = -(long)nb;
		ft_putchar('-');
	}
	if (nb >= 0)
		nbcpy = (long)nb;
	nb_ptr = &nbcpy;
	arr_len = digits_count(nb_ptr);
	populate_arr(nb_ptr, nb_arr, arr_len);
	write_arr(nb_arr, arr_len);
}

int	main(void)
{
	
	ft_putnbr(-150);
	printf("\n");
	ft_putnbr(INT_MAX);
	printf("\n");
	ft_putnbr(INT_MIN);
	printf("\n");
	ft_putnbr(1858);
	printf("\n");
	return(0);
}
