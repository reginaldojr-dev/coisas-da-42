/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wilolive <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/02 17:26:54 by wilolive          #+#    #+#             */
/*   Updated: 2026/03/04 19:30:11 by wilolive         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	write_quads(int *v)
{
	ft_putchar(v[0] + '0');
	ft_putchar(v[1] + '0');
	ft_putchar(' ');
	ft_putchar(v[2] + '0');
	ft_putchar(v[3] + '0');
	if (!(v[0] == 9 && v[1] == 8 && v[2] == 9 && v[3] == 9))
	{
		ft_putchar(',');
		ft_putchar(' ');
	}
}

int	vec_increment(int *v, int len, int base, int step)
{
	int	idx;

	idx = len -1;
	while (idx >= 0)
	{
		v[idx] = v[idx] + step;
		if (v[idx] < base)
			return (1);
		v[idx] = 0;
		idx--;
	}
	return (0);
}

void	ft_print_comb2(void)
{
	int	vec[4];

	vec[0] = 0;
	vec[1] = 0;
	vec[2] = 0;
	vec[3] = 1;
	while (1)
	{
		if ((vec[0] * 10 + vec[1]) < (vec[2] * 10 + vec[3]))
			write_quads(vec);
		if (vec_increment(vec, 4, 10, 1) == 0)
			break ;
	}	
}

int	main(void)
{
	ft_print_comb2();
	return(0);
}
