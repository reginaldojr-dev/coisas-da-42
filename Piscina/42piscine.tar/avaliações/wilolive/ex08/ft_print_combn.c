/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wilolive <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/02 17:43:59 by wilolive          #+#    #+#             */
/*   Updated: 2026/03/03 18:58:14 by wilolive         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	write_pair(int *v)
{
	ft_putchar(v[0] + 48);
	ft_putchar(v[1] + 48);
}

int	vec_increment(int *v, int len, int base, int step)
{
	int	idx;

	idx = len -1;
	while (idx >= 0)
	{
		v[idx] = v[idx] + step;
		if (v[idx] < base)
			return (1);
		v[idx] = 0;
		idx--;
	}
	return (0);
}

int	input_error(int n)
{
	if (n > 0 && n < 10)
		return (1);
	else
		return (0);
}

void	ft_print_combn(int n)
{
	int	vec[2];

	vec[0] = 0;
	vec[1] = 0;
	if (input_error(n) == 0)
		return ;
	vec_increment(vec, 2, 10, 1);
	while (1)
	{
		if (vec[0] < vec[1])
		{
			write_pair(vec);
			if (!(vec[0] == 8 && vec[1] == 9))
			{
				ft_putchar(',');
				ft_putchar(' ');
			}
		}		
		if (vec_increment(vec, 2, 10, 1) == 0)
			break ;
	}
}
