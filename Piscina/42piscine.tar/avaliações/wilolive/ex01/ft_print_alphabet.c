/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wilolive <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/01 19:48:34 by wilolive          #+#    #+#             */
/*   Updated: 2026/03/04 19:13:44 by wilolive         ###   ########.fr       */
/*   Updated: 2026/03/03 20:38:51 by wilolive         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print_alphabet(void)
{
	char	idx;

	idx = 'a';
	while (idx <= 'z')
	{
		ft_putchar(idx);
		idx++;
	}
}

int	main(void)
{
	ft_print_alphabet();
	return('a');
}
