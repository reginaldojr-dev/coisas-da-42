/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wilolive <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/03 18:53:46 by wilolive          #+#    #+#             */
/*   Updated: 2026/03/03 18:54:05 by wilolive         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<unistd.h>

void	ft_putchar(char c);

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_is_negative(int n)
{
	char	positive;
	char	negative;

	positive = 'P';
	negative = 'N';
	if (n < 0)
		ft_putchar(negative);
	if (n >= 0)
		ft_putchar(positive);
}

int	main(void)
{
	ft_is_negative(0);
	ft_is_negative(-1);
	ft_is_negative(1);
	
	return(0);
}
