/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wilolive <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/02 14:04:31 by wilolive          #+#    #+#             */
/*   Updated: 2026/03/03 18:55:11 by wilolive         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	write_triplet(int *v)
{
	ft_putchar(v[0] + 48);
	ft_putchar(v[1] + 48);
	ft_putchar(v[2] + 48);
}

int	vector_increment(int *v, int len, int base, int step)
{
	int	idx;

	idx = len -1;
	while (idx >= 0)
	{
		v[idx] = v[idx] + step;
		if (v[idx] < base)
			return (1);
		v[idx] = 0;
		idx--;
	}
	return (0);
}

void	ft_print_comb(void)
{
	int	vec[3];

	vec[0] = 0;
	vec[1] = 0;
	vec[2] = 0;
	while (1)
	{
		if (vec[0] < vec[1] && vec[1] < vec[2])
		{
			write_triplet(vec);
			if (!(vec[0] == 7 && vec[1] == 8 && vec[2] == 9))
			{
				ft_putchar(',');
				ft_putchar(' ');
			}
		}
		if (vector_increment(vec, 3, 10, 1) == 0)
			break ;
	}
}

int	main(void)
{
	ft_print_comb();
	return(0);
}
