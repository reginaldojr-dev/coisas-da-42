/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgolbert <wgolbert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/08 13:50:41 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 13:15:11 by wgolbert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n);

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (src[i] && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}
// #include <stdio.h>
// int	main(void)
// {
// 	char	src[] = "Hello, world!";
// 	char	dest[50];

// 	ft_strncpy(dest, src, 5);
// 	dest[5] = '\0'; // garantir término para imprimir

// 	printf("Source: %s\n", src);
// 	printf("Dest (n=5): %s\n", dest);

// 	ft_strncpy(dest, src, 20);

// 	printf("Dest (n=20): %s\n", dest);

// 	return (0);
// }