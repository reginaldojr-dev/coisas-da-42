/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgolbert <wgolbert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/11 13:51:58 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 13:15:20 by wgolbert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str);

char	*ft_strlowcase(char *str)
{
	char	*aux;

	aux = str;
	while (*aux)
	{
		if (*aux >= 65 && *aux <= 90)
			*aux += 32;
		aux++;
	}
	return (str);
}
// int main(void){
// 	char a[] = "Oi, todo mundo";
// 	printf("%s", ft_strlowcase(a));
// }