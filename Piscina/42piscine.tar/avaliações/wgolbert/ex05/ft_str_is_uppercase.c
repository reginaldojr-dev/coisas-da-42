/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgolbert <wgolbert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/11 12:23:34 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 13:15:13 by wgolbert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str);

int	ft_str_is_uppercase(char *str)
{
	while (*str)
	{
		if (65 > *str || 90 < *str)
			return (0);
		str++;
	}
	return (1);
}
// #include <stdio.h>
// int	main(void)
// {
// 	printf("Test 1 (\"HELLO\"): %d\n", ft_str_is_uppercase("HELLO"));
// 	printf("Test 2 (\"HELLOWORLD\"): %d\n", ft_str_is_uppercase("HELLOWORLD"));
// 	printf("Test 3 (\"HelloWorld\"): %d\n", ft_str_is_uppercase("HelloWorld"));
// 	printf("Test 4 (\"hello\"): %d\n", ft_str_is_uppercase("hello"));
// 	printf("Test 5 (\"\"): %d\n", ft_str_is_uppercase(""));
// 	printf("Test 6 (\"ABCXYZ\"): %d\n", ft_str_is_uppercase("ABCXYZ"));
// 	printf("Test 7 (\"ABC123\"): %d\n", ft_str_is_uppercase("ABC123"));

// 	return (0);
// }