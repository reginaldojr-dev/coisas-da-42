/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/11 12:23:46 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 19:39:13 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str);

int	ft_str_is_printable(char *str)
{
	while (*str)
	{
		if (*str < 32 || *str > 126)
			return (0);
		str++;
	}
	return (1);
}
#include <stdio.h>
int	main(void)
{
	printf("Test 1 (\"Hello!\"): %d\n", ft_str_is_printable("Hello!"));
	printf("Test 2 (\" \"): %d\n", ft_str_is_printable(" "));
	printf("Test 3 (\"~\"): %d\n", ft_str_is_printable("~"));
	printf("Test 4 (\"Hello\\nWorld\"): %d\n", ft_str_is_printable("Hello\nWorld"));
	printf("Test 5 (\"\"): %d\n", ft_str_is_printable(""));
	printf("Test 6 (\"123ABCabc!@#\"): %d\n", ft_str_is_printable("123ABCabc!@#"));
	printf("Test 7 (\"\t\"): %d\n", ft_str_is_printable("\t"));

	return (0);
}