/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgolbert <wgolbert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/11 11:35:04 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 13:14:58 by wgolbert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str);

int	ft_str_is_numeric(char *str)
{
	while (*str)
	{
		if (*str < 48 || *str > 57)
			return (0);
		str++;
	}
	return (1);
}
// #include <stdio.h>
// int	main(void)
// {
// 	printf("Test 1 (\"12345\"): %d\n", ft_str_is_numeric("12345"));
// 	printf("Test 2 (\"00123\"): %d\n", ft_str_is_numeric("00123"));
// 	printf("Test 3 (\"123a5\"): %d\n", ft_str_is_numeric("123a5"));
// 	printf("Test 4 (\"abc\"): %d\n", ft_str_is_numeric("abc"));
// 	printf("Test 5 (\"\"): %d\n", ft_str_is_numeric(""));
// 	printf("Test 6 (\"42\"): %d\n", ft_str_is_numeric("42"));
// 	printf("Test 7 (\"12 34\"): %d\n", ft_str_is_numeric("12 34"));

// 	return (0);
// }