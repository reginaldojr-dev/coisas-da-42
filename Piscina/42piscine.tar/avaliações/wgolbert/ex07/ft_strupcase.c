/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgolbert <wgolbert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/11 13:16:52 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 13:15:03 by wgolbert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str);

char	*ft_strupcase(char *str)
{
	char	*aux;

	aux = str;
	while (*aux)
	{
		if (*aux >= 97 && *aux <= 122)
			*aux -= 32;
		aux++;
	}
	return (str);
}
// #include <stdio.h>
// int	main(void)
// {
// 	char	str1[] = "hello world!";
// 	char	str2[] = "Hello123";
// 	char	str3[] = "";
// 	char	str4[] = "abcXYZ!@#";

// 	printf("Original: %s -> Uppercase: %s\n", str1, ft_strupcase(str1));
// 	printf("Original: %s -> Uppercase: %s\n", str2, ft_strupcase(str2));
// 	printf("Original: %s -> Uppercase: %s\n", str3, ft_strupcase(str3));
// 	printf("Original: %s -> Uppercase: %s\n", str4, ft_strupcase(str4));

// 	return (0);
// }