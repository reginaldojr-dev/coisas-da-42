/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgolbert <wgolbert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/11 17:21:17 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 13:15:14 by wgolbert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str);

char	*ft_strcapitalize(char *str)
{
	char	*aux;

	aux = str;
	while (*aux)
	{
		if (*aux >= 97 && *aux <= 122)
		{
			*aux -= 32;
			while (*aux != 32 && *aux)
			{
				if ((*aux > 32 && *aux < 48) || (*aux > 57 && *aux < 65)
					|| (*aux > 90 && *aux < 97) || (*aux > 122 && *aux < 127))
					break ;
				aux++;
			}
		}
		else
		{
			while (*aux != 32 && *aux)
				aux++;
		}
		aux++;
	}
	return (str);
}
/*int main(void){
	char c[] = "hi, how are you? 42words forty-two; fifty+and+one";
	ft_strcapitalize(c);
	printf("%s", c);
}
int	main(void)
{
	char str1[] = "hello world";
	char str2[] = "HELLO";      // will cause infinite loop
	char str3[] = "123ABC";     // also problematic

	printf("Before: %s\n", str1);
	printf("After : %s\n", ft_strcapitalize(str1));

	printf("\nTesting problematic case...\n");
	printf("Before: %s\n", str2);
	printf("After : %s\n", ft_strcapitalize(str2)); // program may freeze here

	printf("Before: %s\n", str3);
	printf("After : %s\n", ft_strcapitalize(str3));

	return (0);
}*/