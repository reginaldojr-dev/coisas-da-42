/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgolbert <wgolbert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/09 18:03:33 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 13:15:10 by wgolbert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str);

int	ft_str_is_alpha(char *str)
{
	while (*str)
	{
		if ((65 <= *str && *str <= 90) || (97 <= *str && *str <= 122))
			str++;
		else
			return (0);
	}
	return (1);
}
// #include <stdio.h>
// int	main(void)
// {
// 	printf("Test 1 (\"Hello\"): %d\n", ft_str_is_alpha("Hello"));
// 	printf("Test 2 (\"HelloWorld\"): %d\n", ft_str_is_alpha("HelloWorld"));
// 	printf("Test 3 (\"Hello123\"): %d\n", ft_str_is_alpha("Hello123"));
// 	printf("Test 4 (\"123\"): %d\n", ft_str_is_alpha("123"));
// 	printf("Test 5 (\"\"): %d\n", ft_str_is_alpha(""));
// 	printf("Test 6 (\"abcXYZ\"): %d\n", ft_str_is_alpha("abcXYZ"));
// 	printf("Test 7 (\"abc!\"): %d\n", ft_str_is_alpha("abc!"));

// 	return (0);
// }