/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgolbert <wgolbert@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/11 11:58:50 by wgolbert          #+#    #+#             */
/*   Updated: 2026/03/14 13:15:01 by wgolbert         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str);

int	ft_str_is_lowercase(char *str)
{
	int	c;

	c = 0;
	while (str[c])
	{
		if (str[c] < 97 || str[c] > 122)
			return (0);
		c++;
	}
	return (1);
}
// #include <stdio.h>
// int	main(void)
// {
// 	printf("Test 1 (\"hello\"): %d\n", ft_str_is_lowercase("hello"));
// 	printf("Test 2 (\"helloworld\"): %d\n", ft_str_is_lowercase("helloworld"));
// 	printf("Test 3 (\"helloWorld\"): %d\n", ft_str_is_lowercase("helloWorld"));
// 	printf("Test 4 (\"HELLO\"): %d\n", ft_str_is_lowercase("HELLO"));
// 	printf("Test 5 (\"\"): %d\n", ft_str_is_lowercase(""));
// 	printf("Test 6 (\"abcxyz\"): %d\n", ft_str_is_lowercase("abcxyz"));
// 	printf("Test 7 (\"abc123\"): %d\n", ft_str_is_lowercase("abc123"));

// 	return (0);
// }