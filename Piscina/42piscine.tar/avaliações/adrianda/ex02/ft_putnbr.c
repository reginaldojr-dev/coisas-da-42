/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 23:49:55 by adrianda          #+#    #+#             */
/*   Updated: 2026/03/18 00:53:28 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb)
{
	unsigned int	num;
	char			str;

	if (nb < 0)
	{
		write(1, "-", 1);
		num = (unsigned int) - nb;
	}
	else
		num = (unsigned int)nb;
	if (num >= 10)
	{
		ft_putnbr(num / 10);
	}
	str = (num % 10) + '0';
	write(1, &str, 1);
}
int main(void)
{
    ft_putnbr(42);
    write(1, "\n", 1);
    ft_putnbr(-42);
    write(1, "\n", 1);
    ft_putnbr(0);
    write(1, "\n", 1);
    ft_putnbr(2147483647);
    write(1, "\n", 1);
    ft_putnbr(-2147483648);
    write(1, "\n", 1);
    return (0);
}
