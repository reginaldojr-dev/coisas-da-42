/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 17:52:18 by adrianda          #+#    #+#             */
/*   Updated: 2026/03/18 00:49:55 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

#include <stdio.h>

int main(void)
{
    char *str1 = "Teste";
    char *str2 = "Comprimento desta string";
    char *str3 = "";
    printf("Tamanho da string 1: %d\n", ft_strlen(str1));
    printf("Tamanho da string 2: %d\n", ft_strlen(str2));
    printf("Tamanho da string 3: %d\n", ft_strlen(str3));
    return (0);
}