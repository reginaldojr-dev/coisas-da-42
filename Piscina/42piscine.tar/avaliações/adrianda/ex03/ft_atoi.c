/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 23:49:23 by adrianda          #+#    #+#             */
/*   Updated: 2026/03/18 00:56:19 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(char *str)
{
	int	i;
	int	signal;
	int	num;

	signal = 1;
	num = 0;
	i = 0;
	while ((str[i] >= 9 && str[i] <= 13) || str[i] == 32)
		i++;
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			signal *= -1;
		i++;
	}
	while (str[i] >= 48 && str[i] <= 57)
	{
		num = (num * 10) + (str[i] - 48);
		i++;
	}
	return (num * signal);
}
int main(void)
{
    printf("Básico: %d\n", ft_atoi("42"));
    printf("Negativo: %d\n", ft_atoi("-42"));
    printf("Com espaços: %d\n", ft_atoi("   \t\n 123"));
    printf("Sinais múltiplos: %d\n", ft_atoi("---+--42"));
    printf("Com letras depois: %d\n", ft_atoi("42abc"));
    printf("Zero: %d\n", ft_atoi("0"));
    return (0);
}