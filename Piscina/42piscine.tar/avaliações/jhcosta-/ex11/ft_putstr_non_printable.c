/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/12 14:36:02 by jhcosta-          #+#    #+#             */
/*   Updated: 2026/03/14 19:03:01 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr_non_printable(char *str)
{
	int		i;
	int		first;
	int		second;
	char	*hex;

	hex = "0123456789abcdef";
	i = 0;
	while (str[i])
	{
		if (str[i] >= 32 && str[i] <= 126)
		{
			write(1, &str[i], 1);
		}
		else
		{
			write(1, "\\", 1);
			first = (unsigned char)str[i] / 16;
			second = (unsigned char)str[i] % 16;
			write(1, &hex[first], 1);
			write(1, &hex[second], 1);
		}
		i++;
	}
}

int	main(void)
{
	char	*src;

	src = "Hello\r42\v?";
	ft_putstr_non_printable(src);
}
