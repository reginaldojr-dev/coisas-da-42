/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: araissa- <araissa-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/06 21:54:14 by araissa-          #+#    #+#             */
/*   Updated: 2026/03/10 12:30:11 by araissa-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

#include <stdio.h>
int main(void)
{
	int	x;
	int	y;
	int	div;
	int	mod;

	x = 45;
	y = 10;
	printf("x =%d, y = %d \n", x, y);
	ft_div_mod(x, y, &div, &mod);
	printf("Divisão: %d \n", div);
	printf("Resto: %d \n", mod);
}
