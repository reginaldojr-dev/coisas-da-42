/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: araissa- <araissa-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/09 16:00:44 by araissa-          #+#    #+#             */
/*   Updated: 2026/03/10 12:42:29 by araissa-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	temp;
	int	i;
	int	j;

	i = 0;
	j = size - 1;
	while (i < j)
	{
		temp = tab[i];
		tab[i] = tab[j];
		tab[j] = temp;
		i++;
		j--;
	}
}
#include <stdio.h>
int main(void)
{
int array[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
int size = 10;

int print = 0;

ft_rev_int_tab(array,size);

while (print < size)
{
printf("%d", array[print]);
print++;
}
return (0);
}