/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: araissa- <araissa-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/06 20:12:44 by araissa-          #+#    #+#             */
/*   Updated: 2026/03/10 12:25:02 by araissa-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
#include <stdio.h>
int	main(void)
{

	int	novo_valor;

	novo_valor = 0;
	int *p1 = &novo_valor;
	int	**p2 = &p1;
	int	***p3 = &p2;
	int	****p4 = &p3;
	int	*****p5 = &p4;
	int	******p6 = &p5;
	int	*******p7 = &p6;
	int	********p8 = &p7;
	int	*********p9 = &p8;

	printf("Antes:%d \n", novo_valor);
	ft_ultimate_ft(p9);
	printf("Depois:%d \n", novo_valor);
	return (0);
}
