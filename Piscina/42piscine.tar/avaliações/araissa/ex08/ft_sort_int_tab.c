/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: araissa- <araissa-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/09 17:14:54 by araissa-          #+#    #+#             */
/*   Updated: 2026/03/10 12:44:18 by araissa-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int	temp;
	int	i;
	int	j;

	j = 0;
	while (j < size)
	{
		i = 0;
		while (i < size - 1)
		{
			if (tab[i] > tab[i + 1])
			{
				temp = tab[i];
				tab[i] = tab[i + 1];
				tab[i + 1] = temp;
			}
			i++;
		}
		j++;
	}
}

#include <stdio.h>

int main(void)
{
	int array[10] = {9, 7, 2, 6, 4, 3, 5, 0, 1, 8};
	int	size = 10;
	int	print = 0;


	ft_sort_int_tab(array, size);

	while (print < size)
	{
		printf("%d", array[print]);
		print++;
	}
	return (0);
}