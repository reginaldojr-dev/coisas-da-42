/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: araissa- <araissa-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/06 22:15:10 by araissa-          #+#    #+#             */
/*   Updated: 2026/03/10 12:32:25 by araissa-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = temp / *b;
	*b = temp % *b;
}
#include <stdio.h>

int	main(void)
{
	int	x;
	int	y;

	x = 10;
	y = 5;
	printf("valor de a = %d, valor de b = %d;\n", x, y);
	ft_ultimate_div_mod(&x, &y);
	printf("Divisão - valor de a = %d;\n", x);
	printf("resto -  valor de b = %d;\n", y);

}
