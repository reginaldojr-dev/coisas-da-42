/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: araissa- <araissa-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/06 21:16:48 by araissa-          #+#    #+#             */
/*   Updated: 2026/03/10 12:27:25 by araissa-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

#include <stdio.h>

int	main(void)
{
	int x = 20;
	int y = 45;

	printf("Antes a = %d \n", x);
	printf("Antes b = %d \n", y);
	ft_swap(&x, &y);
	printf("Depois a = %d \n", x);
	printf("Depois b = %d \n", y);
}

