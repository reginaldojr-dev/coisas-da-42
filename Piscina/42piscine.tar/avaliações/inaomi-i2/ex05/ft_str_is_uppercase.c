/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 01:54:30 by inaomi-i          #+#    #+#             */
/*   Updated: 2026/03/19 23:11:03 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!((str[i] >= 'A' && str[i] <= 'Z')))
			return (0);
		i++;
	}
	return (1);
}
#include <stdio.h>

int	main(void)
{
	ft_str_is_uppercase("");
	printf("%d\n", ft_str_is_uppercase("NAOMI"));
	printf("%d\n", ft_str_is_uppercase("sa1"));
	printf("%d\n", ft_str_is_uppercase(""));
}
