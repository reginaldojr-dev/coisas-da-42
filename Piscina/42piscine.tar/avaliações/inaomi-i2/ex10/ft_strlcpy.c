/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 21:11:55 by inaomi-i          #+#    #+#             */
/*   Updated: 2026/03/19 23:17:25 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;

	i = 0;
	if (size == 0)
	{
		while (src[i])
			i++;
		return (i);
	}
	while (src[i] && i < size - 1)
	{
		dest[i] = src[i];
		i++;
	}
	while (src[i])
		i++;
	dest[i] = '\0';
	return (i);
}
#include <stdio.h>

int	main(void)
{
	char	dest[10];
	char	src[] = "Piscine42";

	ft_strlcpy(dest, src, 3);
	printf("%s", dest);
	return (0);
}
