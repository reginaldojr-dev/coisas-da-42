/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 20:03:43 by inaomi-i          #+#    #+#             */
/*   Updated: 2026/03/19 23:14:19 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		if (i == 0 || !((str[i - 1] >= 'a' && str[i - 1] <= 'z') || (str[i
						- 1] >= 'A' && str[i - 1] <= 'Z') || (str[i - 1] >= '0'
					&& str[i - 1] <= '9')))
		{
			if (str[i] >= 'a' && str[i] <= 'z')
				str[i] -= 32;
		}
		i++;
	}
	return (str);
}
#include <stdio.h>

int	main(void)
{
	char str1[] = "hi, how are you? 42words forty-two; fifty+and+one";
	char str2[] = "sSSa1 asdsadas ";
	char str3[] = "adasdsa";

	printf("%s\n", ft_strcapitalize(str1));
	printf("%s\n", ft_strcapitalize(str2));
	printf("%s\n", ft_strcapitalize(str3));
	return (0);
}