/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 01:52:32 by inaomi-i          #+#    #+#             */
/*   Updated: 2026/03/19 23:09:53 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!((str[i] >= 'a' && str[i] <= 'z')))
			return (0);
		i++;
	}
	return (1);
}
#include <stdio.h>

int	main(void)
{
	ft_str_is_lowercase("saa");
	printf("%d\n", ft_str_is_lowercase("NAOMI"));
	printf("%d\n", ft_str_is_lowercase("sasadsd"));
	printf("%d\n", ft_str_is_lowercase(""));
}
