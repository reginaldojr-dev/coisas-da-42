/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 01:47:12 by inaomi-i          #+#    #+#             */
/*   Updated: 2026/03/19 23:09:27 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!((str[i] >= '0' && str[i] <= '9')))
			return (0);
		i++;
	}
	return (1);
}
#include <stdio.h>

int	main(void)
{
	ft_str_is_numeric("saa");
	printf("%d\n", ft_str_is_numeric("saa"));
	printf("%d\n", ft_str_is_numeric("1"));
	printf("%d\n", ft_str_is_numeric(""));
}
