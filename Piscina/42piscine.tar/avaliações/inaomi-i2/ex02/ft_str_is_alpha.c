/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 01:11:46 by inaomi-i          #+#    #+#             */
/*   Updated: 2026/03/19 23:08:42 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A'
					&& str[i] <= 'Z')))
			return (0);
		i++;
	}
	return (1);
}
#include <stdio.h>

int	main(void)
{
	ft_str_is_alpha("saa");
	printf("%d\n", ft_str_is_alpha("saa"));
	printf("%d\n", ft_str_is_alpha("sa1"));
	printf("%d\n", ft_str_is_alpha(""));
}
