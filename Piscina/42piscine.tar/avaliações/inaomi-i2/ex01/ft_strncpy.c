/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 21:30:53 by inaomi-i          #+#    #+#             */
/*   Updated: 2026/03/19 23:07:35 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n && src[i])
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

#include <stdio.h>

int	main(void)
{
	char dest1[20] = "------";
	char dest2[20] = "------";
	char dest3[20] = "------";

	printf("ANTES:\n");
	printf("dest1: %s\n", dest1);
	printf("dest2: %s\n", dest2);
	printf("dest3: %s\n\n", dest3);

	ft_strncpy(dest1, "Piscine42", 3);
	ft_strncpy(dest2, "Piscine42", 5);
	ft_strncpy(dest3, "Piscine42", 7);

	printf("DEPOIS:\n");
	printf("n = 3 → %s\n", dest1);
	printf("n = 5 → %s\n", dest2);
	printf("n = 7 → %s\n", dest3);

	return (0);
}