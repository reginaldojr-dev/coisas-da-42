/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 01:57:10 by inaomi-i          #+#    #+#             */
/*   Updated: 2026/03/19 23:12:17 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (!(*str >= 32 && *str <= 126))
			return (0);
		i++;
	}
	return (1);
}
#include <stdio.h>

int	main(void)
{
	ft_str_is_printable("saa");
	printf("%d\n", ft_str_is_printable("saa"));
	printf("%d\n", ft_str_is_printable("\n"));
	printf("%d\n", ft_str_is_printable(""));
}