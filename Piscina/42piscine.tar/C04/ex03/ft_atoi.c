/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 18:58:55 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/19 23:21:47 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(char *str)
{
	int	i;
	int	signal;
	int	result;

	i = 0;
	signal = 1;
	result = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
	{
			i++;
	}
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
		signal *= -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		result = (result * 10) + (str[i] - '0');
		i++;
	}
	return (result * signal);
}

#include <stdio.h>

int	main(void)
{
	printf("Test 1: %d\n", ft_atoi("42"));
    printf("Test 2: %d\n", ft_atoi("   42"));
    printf("Test 3: %d\n", ft_atoi("   -42"));
    printf("Test 4: %d\n", ft_atoi("   +42"));
    printf("Test 5: %d\n", ft_atoi("123abc"));
    printf("Test 6: %d\n", ft_atoi("abc123"));
    printf("Test 7: %d\n", ft_atoi("   \n\t\v\f\r 56"));
    printf("Test 8: %d\n", ft_atoi("--123"));
    printf("Test 9: %d\n", ft_atoi("++123"));
    printf("Test 10: %d\n", ft_atoi("+-123"));
    printf("Test 11: %d\n", ft_atoi("-+123"));
    printf("Test 12: %d\n", ft_atoi(""));
    printf("Test 13: %d\n", ft_atoi("0"));
    printf("Test 14: %d\n", ft_atoi("-0"));
	return (0);
}
