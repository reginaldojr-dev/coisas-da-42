/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 15:16:17 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/19 15:16:19 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	index;

	index = 0;
	while (str[index] != '\0')
	{
		index++;
	}
	return (index);
}

// #include <stdio.h>

// int	main(void)
// {
// 	char	str[] = "testando";
// 	int	size;
// 	size = ft_strlen(str);

// 	printf("%d\n", size);
// 	return (0);
// }
