/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/14 21:58:26 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/14 22:29:10 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!((str[i] >= 'a' && str[i] <= 'z')
				|| (str[i] == '\0')))
		{
			return (0);
		}
		i++;
	}
	return (1);
}

// #include <stdio.h>

// int	main (void)
// {
// 	printf("%d\n", ft_str_is_lowercase("ABACATE"));
// 	printf("%d\n", ft_str_is_lowercase("abacate"));
// 	printf("%d\n", ft_str_is_lowercase(""));
// }