/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgoulart <rgoulart@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/15 19:34:34 by rgoulart          #+#    #+#             */
/*   Updated: 2026/03/16 17:32:39 by rgoulart         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned	int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	len;
	unsigned int	i;

	len = 0;
	while (src[len] != '\0')
		len++;
	if (size == 0)
	{
		return (len);
	}
	i = 0;
	while (src [i] != '\0' && i < size - 1)
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (len);
}

// #include <stdio.h>

// int	main(void)
// {
// 	char	src[] = "Exemplo de texto longo";
// 	char	dest[6];
// 	ft_strlcpy(dest, src, 6);

// 	printf("%s\n", dest);
// 	return(0);
// }